import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime
from flask import Flask, render_template, request
import threading
import sqlite3

class Scraping_dataa:

    def Data_Scrapper(self,link):
        self.r1 = requests.get(link)
        self.c1 = self.r1.content
        self.soup_1 = BeautifulSoup(self.c1, "html.parser")
        return self.soup_1

    def Data(self, LIST, col, repl_1, repl_2, repl_3, repl_4, lsst):
        for i in LIST:
            d = {}
            date_time_str = i.find_all("td")[0].text
            date_time_obj = datetime.strptime(date_time_str, '%A %d %B %Y')
            d["Date"] = date_time_obj
            d["Price"] = i.find_all("td")[1].text.replace(repl_1, repl_2).replace(repl_3, repl_4)
            lsst.append(d)

    def Csv_file(self, LIST, filename):
        df = pd.DataFrame(LIST)
        df = df.sort_values(['Date'], ascending = False)
        df.to_csv(filename, index = False)