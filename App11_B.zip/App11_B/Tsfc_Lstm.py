import os
import plotly.graph_objects as go
import matplotlib.pyplot as plt
import plotly.express as px
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from statsmodels.tsa.seasonal import seasonal_decompose
import seaborn as sns
import plotly.figure_factory as ff
from keras.models import Sequential
from keras.models import load_model
from keras.layers import LSTM,Dropout,Dense
from sklearn.preprocessing import MinMaxScaler
import warnings
from plotly.subplots import make_subplots
from plotly.graph_objs import Line
from see_rnn import *
from sklearn.metrics import mean_squared_error
warnings.filterwarnings("ignore", category=DeprecationWarning)

class Tsfc_Lstm__:
    global dff
    def data_pre_process(self,dff,date_today):
        self.dff = dff.sort_values(by='Date')
        self.dff.set_index('Date',inplace=True)
        idx = pd.date_range(start='2022-05-11', end=date_today-timedelta(days = 1))
        self.dff = self.dff.reindex(idx)
        self.dff.index.names = ['Date']
        self.dff = self.dff.interpolate(method ='linear', limit_direction ='backward')
        return self.dff
    
    def predicted_value__(self, df):
        self.df = df
        size = int(len(self.df))
        self.df= self.df.values
        self.df = self.df[1:len(self.df),0]

        scaler=MinMaxScaler(feature_range=(0,1))
        scaled_data=scaler.fit_transform(self.df.reshape(-1,1))

        self.df=self.df.reshape(-1,1)
        self.df=scaler.transform(self.df)

        X_test=[]
        for i in range(50,int(self.df.shape[0])):
            X_test.append(self.df[i-50:i,0])
        X_test=np.array(X_test)
        X_test=np.reshape(X_test,(X_test.shape[0],X_test.shape[1],1))

        lstm_model=Sequential()
        lstm_model.add(LSTM(units=64,return_sequences=True,input_shape=(X_test.shape[1],1)))
        lstm_model.add(LSTM(units=64))
        lstm_model.add(Dense(1))
        lstm_model.load_weights("my_model.h5")
        y_hat = lstm_model.predict(X_test)
        y_hat = scaler.inverse_transform(y_hat)
        df = df.iloc[51:]
        df['Predicted_Price'] = y_hat
        #print(df)
        return df