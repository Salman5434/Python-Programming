import requests
from bs4 import BeautifulSoup
import numpy as np
import pandas as pd
import datetime
from datetime import timedelta
from flask import Flask, render_template, request
import threading
import sqlite3
import time
from Scrapping_Data import Scraping_dataa
from Tsfc_Lstm import Tsfc_Lstm__
import Database
from sklearn.metrics import mean_squared_error, classification_report
import warnings
warnings.filterwarnings('ignore')

app = Flask(__name__)

object1 = Scraping_dataa()
object2 = Scraping_dataa()
object3 = Tsfc_Lstm__()
object4 = Tsfc_Lstm__()

l1 =[]
l2 = []

try:
    soup1 = object1.Data_Scrapper("https://www.exchangerates.org.uk/USD-PKR-exchange-rate-history.html")
    all = soup1.find_all("table",{"id":"hist"})

    list1 = all[0].find_all("tr",{"class":"colone"})
    list2 = all[0].find_all("tr",{"class":"coltwo"})

    object1.Data(list1, "USD-PKR", "1 USD = ", "", " PKR", "", l1)
    object1.Data(list2, "USD-PKR", "1 USD = ", "", " PKR", "", l1)
    object1.Csv_file(l1, "USD-to-PKR.csv")
    l1 = pd.DataFrame(l1)
except:
    l1 = pd.csv.read("USD-to-PKR.csv")
    print("Website not working")

try:
    soup2 = object2.Data_Scrapper("https://www.exchangerates.org.uk/PKR-USD-exchange-rate-history.html")
    all = soup2.find_all("table",{"id":"hist"})

    list3 = all[0].find_all("tr",{"class":"colone"})
    list4 = all[0].find_all("tr",{"class":"coltwo"})

    object2.Data(list3, "PKR-USD", "1 PKR = ", "", " USD", "", l2)
    object2.Data(list4, "PKR-USD", "1 PKR = ", "", " USD", "", l2)
    object2.Csv_file(l2, "PKR-to-USD.csv")
    l2 = pd.DataFrame(l2)
except:
    l2 = pd.csv.read("PKR-to-USD.csv")
    print("Website not working")

Scraped_Data_USD = pd.read_csv("USD-to-PKR.csv", parse_dates = ['Date'])
df1 = Scraped_Data_USD
current_date = datetime.date.today()
df1 = df1.append({'Date':current_date}, ignore_index=True)

Scraped_Data_USD['Daily'] = Scraped_Data_USD['Date'].dt.strftime('%Y - %m - %d')
Scraped_Data_PKR = pd.read_csv("PKR-To-USD.csv", parse_dates = ['Date'])
Scraped_Data_PKR['Daily'] = Scraped_Data_PKR['Date'].dt.strftime('%Y - %m - %d')

def Tick_Data():
    global pkr, predicted_value, current_date
    while True:
        r3 = requests.get("https://www.x-rates.com/table/?from=USD&amount=1")
        c3 = r3.content
        soup3 = BeautifulSoup(c3, "html.parser")
        
        try:
            if soup3.find("table", {"class" : "tablesorter ratesTable"}).text is not None:
                Usdt = soup3.find("table", {"class" : "tablesorter ratesTable"}).text
                Usdt = Usdt.split()
                index = Usdt.index("Pakistani")
                pkr = Usdt[index+2:index+4]
        except:
            pkr = [None, None]

        df1.iloc[-1, df1.columns.get_loc('Price')] = float(pkr[0])
        data = object3.data_pre_process(df1, current_date)

        predicted_value = object3.predicted_value__(data)
        predicted_value_ = predicted_value["Predicted_Price"].values[-1]

        db = Database.Databases("lite.db")
        currentDateTime = datetime.datetime.now()
        db.Insert_Values(float(pkr[0]), float(pkr[1]), currentDateTime)
        db.Updated_Values()
        ROI = round(((predicted_value_ - float(pkr[0]))/float(pkr[0])) * 100, 3)
        # print(ROI)
        time.sleep(60)

def Data_Convertor(df, col, conv):
    df[col] = df['Date'].dt.strftime(conv) 
    avg = df.groupby([col]).mean()
    return avg

@app.route('/')
def home():
    date_time = datetime.datetime.now()
    return render_template("home.html", Pkrt = pkr[0], Usdt = pkr[1], date_time = date_time, y = predicted_value)

@app.route('/Return', methods = ["POST"])
def Return():
    date_time = datetime.datetime.now()
    return render_template("home.html", Pkrt = pkr[1], Usdt = pkr[0], date_time = date_time, y = predicted_value)

@app.route('/forecast')
def forecasted():
    return render_template('predict.html')

@app.route('/forecast', methods = ['GET','POST'])
def forecast():
    try:
        if request.method == 'POST':
            start_date = request.form["start_date"]
            start_date1 = datetime.datetime.strptime(start_date, '%Y-%m-%d').date()
            start_date2 = datetime.datetime.strptime(start_date, '%Y-%m-%d').date()
            last_date = datetime.date.today()
            end_date = request.form["end_date"]
            end_date2 = datetime.datetime.strptime(end_date, '%Y-%m-%d').date()

        try:
            investment_amount = float(request.form["investment"])
        except:
            investment_amount = 1

        diff = ((end_date2) - (start_date1)).days + 1

        # print("---------------------")
        # print(start_date1)
        # print(end_date2)
        # print(diff)
        # print(investment_amount)
        # print("---------------------")

        dataaa = df1[df1['Date'] <= start_date1]
        data_p = object4.data_pre_process(dataaa, start_date1)
        pridict = []
        flag = 0
        if start_date1 > last_date or end_date2 > last_date:
            
            for i in range(diff):
                flag = 1
                predicted_value = object3.predicted_value__(data_p)
                # print(predicted_value)
                predicted_value = predicted_value.reset_index()
                new_price = predicted_value["Predicted_Price"].values[-1]
                new_price_ = {'Price':new_price}
                pridict.append(new_price)
                #print(new_price_)
                data_p = data_p.append(pd.DataFrame(new_price_, index=[start_date1]))
                start_date1 = start_date1 + timedelta (days = 1)
                #print(data_p)
        else:
            for i in range(diff):
                flag = 2
                predicted_value = object3.predicted_value__(data_p)
                predicted_value = predicted_value.reset_index()
                new_price = predicted_value["Predicted_Price"].values[-1]
                new_price_ = {'Price':new_price}
                pridict.append(new_price)
                data_p = data_p.append(pd.DataFrame(new_price_, index=[start_date1]))
                start_date1 = start_date1 + timedelta (days = 1)

        actual_data = df1[(df1['Date'] >= start_date2) & (df1['Date'] <=end_date2)]
        actual_data["Forecastings"] =  pridict
        actual_data = actual_data.reset_index()

        t_a = []
        t_p = []

        for i in range(diff):
            if i < diff - 1:
                if actual_data['Price'][i] < actual_data['Price'][i+1]:
                    t_a.append(1)
                else: 
                    t_a.append(0)
            else:
                t_a.append(np.nan)

        for i in range(diff):
            if i < diff - 1:
                if actual_data['Forecastings'][i] < actual_data['Forecastings'][i+1]:
                    t_p.append(1)
                else: 
                    t_p.append(0)
            else:
                t_p.append(np.nan)

        actual_data['Orignal_Trend'] = t_a
        actual_data['Forecasted_Trend'] = t_p
        print(actual_data)

        actual_data1 = actual_data.copy()
        actual_data1 = actual_data1.dropna()
        classify_report = classification_report(actual_data1['Orignal_Trend'], actual_data1['Forecasted_Trend'], output_dict=True)
        classify_report = pd.DataFrame(classify_report).transpose()
        classify_report_new = classify_report
        print(type(classify_report))
        iv = df1['Price'][df1['Date'] == (start_date2 - datetime.timedelta(days = 1))].values
        roi = ((pridict[-1] - iv)/iv) * 100
        ROI_new = roi
        print(ROI_new)
        message = "If ROI is negative <strong>don't bother investing </strong>, If ROI is positive then <strong> invest </strong> as much as want."

        return render_template('predict.html', Pkrt = pkr[1], y = predicted_value, roi = "Return on Investment(roi) = " + str(ROI_new), message = message,  cr = "Classifier report " + classify_report_new.to_html(), ad =  "Forecasted Values" + actual_data.to_html() if flag != 1 else "", new =  "<strong> Future Prediction </strong>" + predicted_value.to_html() if flag == 1 else "")
    except:
        return render_template('predict.html', Pkrt = pkr[1], y = predicted_value, ad = "Forecasted Values" + actual_data.to_html() if flag != 1 else "", new = "Future Prediction " + predicted_value.to_html() if flag == 1 else "")

@app.route('/USD_To_PKR_Data', methods = ['POST'])
def display():
    try:
        if request.method == 'POST':
            return render_template("USD_To_PKR.html", datafr = l1.to_html())
    except:
        return render_template("home.html")

@app.route('/PKR_To_USD_Data', methods = ['POST'])
def displays():
    try:
        if request.method == 'POST':
            return render_template("PKR_To_USD.html", datafr1 = l2.to_html())
    except:
        return render_template("home.html")

@app.route('/Tick_Graph')
def showDataUSD():
    return render_template("graphs.html", y = Database.Dollar_value[-100:], x = Database.timee_stamp[-100:])

@app.route('/Weekly_Graph')
def weeklyDataUSD():
    wk_Avg = Data_Convertor(Scraped_Data_USD, 'Week', '%U - %Y')
    return render_template("graphs.html", y = list(wk_Avg['Price']), x = list(wk_Avg.index))

@app.route('/Monthly_Graph')
def monthlyDataUSD():
    Mnt_Avg = Data_Convertor(Scraped_Data_USD,'Month', '%m - %Y')
    return render_template("graphs.html", y = list(Mnt_Avg['Price']), x = list(Mnt_Avg.index))

@app.route('/Tick_Graph1')
def showDataPKR():
    return render_template("graphs1.html", y = Database.Rupee_value[-100:], x = Database.timee_stamp[-100:])
    
@app.route('/Weekly_Graph1')
def weeklyDataPKR():
    wk_Avg1 = Data_Convertor(Scraped_Data_PKR, 'Week', '%U - %Y')
    return render_template("graphs1.html", y = list(wk_Avg1['Price']), x = list(wk_Avg1.index))

@app.route('/Monthly_Graph1')
def monthlyDataPKR():
    Mnt_Avg1 = Data_Convertor(Scraped_Data_PKR,'Month', '%m - %Y')
    return render_template("graphs1.html", y = list(Mnt_Avg1['Price']), x = list(Mnt_Avg1.index))


if __name__ == "__main__":
    thread1 = threading.Thread(target = Tick_Data).start()
    thread2 = threading.Thread(target = app.run(debug = True)).start()