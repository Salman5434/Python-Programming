# import pandas
# from datetime import datetime
# from pytz import utc

# data = pandas.read_csv('reviews.csv', parse_dates = ['Timestamp'])

# print(data.head())

# print(data.head())
# print(data.shape)
# print(data.columns)
# print(data.hist('Rating'))

# ## selecting data from data frame
# print(data['Rating'].mean())                     ## select a column
# print(data[['Course Name','Rating']])            ## select multiple columns
# print(data.iloc[3])                              ## selct a row
# print(data.iloc[1:3])                            ## selct multiple rows
# print(data[['Course Name','Rating']].iloc[1:3])  ## select a section
# print(data['Timestamp'].iloc[3])                 ## select a cell
# print(data.at[3, 'Rating'])                      ## preferred methiod to select a cell

# ## filtering data on conditions
# print(data[data['Rating'] > 4])                 ## one condition
# print(len(data[data['Rating'] > 4]))            ## length of one condition
# print(data [data['Rating'] > 4].count())         ## length of one condition using count

###########################################

# # d2 = data[data['Rating'] > 4]                   ## one condition and data of just one column
# # print(d2['Rating'])

# # print(data[(data['Rating'] > 4) & (data['Course Name'] == 'The Complete Python Course: Build 10 Professional OOP Apps')])    ## multiple conditions

# # ## time based filtering
# # print(data[(data['Timestamp'] >= datetime(2020, 7, 1, tzinfo = utc)) & (data['Timestamp'] <= datetime(2020, 12, 31, tzinfo = utc))])  ## filtering time using multiple condition\

# ############################################

# print(data['Rating'].mean())   ## avg rating

# print(data[data['Course Name'] == 'The Python Mega Course: Build 10 Real World Applications']['Rating'].mean()) ## avg rating for particular course

# ## avg rating for particular course 
# print(data[(data['Rating'] > 4) & (data['Course Name'] == 'The Complete Python Course: Build 10 Professional OOP Apps')]['Rating'].mean())

# ## avg rating for particular period
# print(data[(data['Timestamp'] >= datetime(2020, 7, 1, tzinfo = utc)) & (data['Timestamp'] <= datetime(2020, 12, 31, tzinfo = utc))]['Rating'].mean())

# ## avg rating for a particular period and particular course
# print(data[(data['Timestamp'] >= datetime(2020, 1, 1, tzinfo = utc)) & (data['Timestamp'] <= datetime(2020, 12, 31, tzinfo = utc)) & 
# (data['Course Name'] == 'The Python Mega Course: Build 10 Real World Applications')]['Rating'].mean())


# ## avg uncommented and commented ratings
# print(data[data['Comment'].isnull()]['Rating'].mean())
# print(data[data['Comment'].notnull()]['Rating'].mean())

# ## no of uncommented and commented ratings
# print(data[data['Comment'].isnull()]['Rating'].count())
# print(data[data['Comment'].notnull()]['Rating'].count())

# ## no of comments with certain words
# print(data[data['Comment'].str.contains('accent', na = False)]['Rating'].count())

##########################################
## Day avg using matplotlib library

# import pandas
# from datetime import datetime
# from pytz import utc
# import matplotlib.pyplot as plt

# data = pandas.read_csv('reviews.csv', parse_dates = ['Timestamp'])

# print(data.head())

# data['Day'] = data['Timestamp'].dt.date
# day_avg = data.groupby(['Day']).mean()

# print(day_avg.head())
# print(day_avg.index)

# plt.figure(figsize = (25, 3))
# plt.plot(day_avg.index, day_avg['Rating'])

###################################
## Week avg using matplotlib library

# import pandas
# from datetime import datetime
# from pytz import utc
# import matplotlib.pyplot as plt

# data = pandas.read_csv('reviews.csv', parse_dates = ['Timestamp'])

# data['Week'] = data['Timestamp'].dt.strftime('%Y-%U')
# week_avg = data.groupby(['Week']).mean()

# plt.figure(figsize = (25, 3))
# plt.plot(week_avg.index, week_avg['Rating'])

# ###################################
# ## Month avg using matplotlib library

# import pandas
# from datetime import datetime
# from pytz import utc
# import matplotlib.pyplot as plt

# data = pandas.read_csv('reviews.csv', parse_dates = ['Timestamp'])

# data['Month'] = data['Timestamp'].dt.strftime('%Y-%m')
# month_avg = data.groupby(['Month']).mean()

# plt.figure(figsize = (25, 3))
# plt.plot(month_avg.index, month_avg['Rating'])

###################################
## Month avg plot using matplotlib library

# import pandas
# from datetime import datetime
# from pytz import utc
# import matplotlib.pyplot as plt

# data = pandas.read_csv('reviews.csv', parse_dates = ['Timestamp'])

# data['Month'] = data['Timestamp'].dt.strftime('%Y-%m')
# month_avg_crs = data.groupby(['Month', 'Course Name']).mean().unstack()

# month_avg_crs.plot(figsize = (25,8))

###################################
## Week at people give good rating

#import pandas
# from datetime import datetime
# from pytz import utc
# import matplotlib.pyplot as plt

# data = pandas.read_csv('reviews.csv', parse_dates = ['Timestamp'])

# data['Week'] = data['Timestamp'].dt.strftime('%A')
# week_avg = data.groupby(['Week', 'day_num']).mean()
# week_avg = week_avg.sort_values('Week')
# plt.plot(week_avg.index, week_avg['Rating'])

###################################
## day at people give good rating

#import pandas
# from datetime import datetime
# from pytz import utc
# import matplotlib.pyplot as plt

# data = pandas.read_csv('reviews.csv', parse_dates = ['Timestamp'])

# data['Day_num'] = data['Timestamp'].dt.strftime('%w')
# day_num_avg = data.groupby(['Day_num']).mean()
# day_num_avg = day_num_avg.sort_values('Day_num')
# plt.plot(day_num_avg.index.get_level_values(0), day_num_avg['Rating'])

###################################
## no of ratings by course

# import pandas
# from datetime import datetime
# from pytz import utc
# import matplotlib.pyplot as plt

# data = pandas.read_csv('reviews.csv', parse_dates = ['Timestamp'])

# share = data.groupby(['Course Name'])['Rating'].count()
# print(share)
# plt.pie(share, labels = share.index)