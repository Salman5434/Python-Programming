import justpy as jp
import pandas
from datetime import datetime
from pytz import utc
import matplotlib.pyplot as plt

data = pandas.read_csv('reviews.csv', parse_dates = ['Timestamp'])
data['Month'] = data['Timestamp'].dt.strftime('%Y-%m')
month_avg_crs = data.groupby(['Month', 'Course Name']).count().unstack()
print(month_avg_crs)

## for Highcharts https://www.highcharts.com/docs/chart-and-series-types/pie-chart
chart_def = '''
{
    chart: {
        type: 'spline'
    },
    title: {
        text: 'Moose and deer hunting in Norway, 2000 - 2021'
    },
    subtitle: {
        align: 'center',
        text: 'Source: <a href="https://www.ssb.no/jord-skog-jakt-og-fiskeri/jakt" target="_blank">SSB</a>'
    },
    legend: {
        layout: 'vertical',
        align: 'left',
        verticalAlign: 'top',
        x: 120,
        y: 70,
        floating: false,
        borderWidth: 1,
        backgroundColor:
            '#FFFFFF'
    },
    xAxis: {
        categories: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
        plotBands: [{ // Highlight the two last years
            from: 4.5,
            to: 6.5,
            color: 'rgba(68, 170, 213, .2)'
        }]
    },
    yAxis: {
        title: {
            text: 'Quantity'
        }
    },
    tooltip: {
        shared: true,
        headerFormat: '<b>Hunting season starting autumn {point.x}</b><br>'
    },
    credits: {
        enabled: false
    },
    plotOptions: {
        series: {
            pointStart: 2000
        },
        areaspline: {
            fillOpacity: 0.5
        }
    },
    series: []
}
'''

def app():
    webpage = jp.QuasarPage()
    heading = jp.QDiv(a = webpage, text = 'Analysis of course reviews', classes = 'text-h3 text-center q-pa-md') ## https://quasar.dev/style/typography
    paragraph = jp.QDiv(a = webpage, text = 'These graphs represent course analaysis')
    highchart = jp.HighCharts(a = webpage, options = chart_def)
    
    highchart.options.title.text = 'Avg rating by Month'
    highchart.options.xAxis.categories = list(month_avg_crs.index)

    highchart_data = [{"name": v1, 'data': [v2 for v2 in month_avg_crs[v1]]} for v1 in month_avg_crs.columns]
    highchart.options.series = highchart_data

    return webpage
    
jp.justpy(app)