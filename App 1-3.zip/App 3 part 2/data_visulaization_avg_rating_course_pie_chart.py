import justpy as jp
import pandas
from datetime import datetime
from pytz import utc
import matplotlib.pyplot as plt

data = pandas.read_csv('reviews.csv', parse_dates = ['Timestamp'])
share = data.groupby(['Course Name'])['Rating'].count()

## for Highcharts https://www.highcharts.com/docs/chart-and-series-types/pie-chart
chart_def = '''
{
    chart: {
        type: 'pie'
    },
    title: {
        text: 'Browser market shares in May, 2020'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    accessibility: {
        point: {
            valueSuffix: '%'
        }
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.1f} %'
            }
        }
    },
    series: [{
        name: 'Brands',
        colorByPoint: true,
        data: [{
            name: 'Chrome',
            y: 70.67,
            sliced: true,
            selected: true
        }, {
            name: 'Edge',
            y: 14.77
        },  {
            name: 'Firefox',
            y: 4.86
        }, {
            name: 'Safari',
            y: 2.63
        }, {
            name: 'Internet Explorer',
            y: 1.53
        },  {
            name: 'Opera',
            y: 1.40
        }, {
            name: 'Sogou Explorer',
            y: 0.84
        }, {
            name: 'QQ',
            y: 0.51
        }, {
            name: 'Other',
            y: 2.6
        }]
    }]
}
'''

def app():
    webpage = jp.QuasarPage()
    heading = jp.QDiv(a = webpage, text = 'Analysis of course reviews', classes = 'text-h3 text-center q-pa-md') ## https://quasar.dev/style/typography
    paragraph = jp.QDiv(a = webpage, text = 'These graphs represent course analaysis')
    highchart = jp.HighCharts(a = webpage, options = chart_def)
    
    highchart.options.title.text = 'Avg rating by Month'

    highchart_data = [{"name": v1, 'y': v2 } for v1,v2 in zip(share.index, share)]
    highchart.options.series[0].data = highchart_data

    return webpage
    
jp.justpy(app)