from flask import Flask, render_template, request, send_file
import pandas as pd
from werkzeug.utils import secure_filename
from geopy.geocoders import ArcGIS

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')


@app.route('/show_data',  methods=["POST"])
def showData():
    global up_file
    global content

    try:
        if request.method == 'POST':
            up_file = request.files["uploaded-file"]
            content = pd.read_csv(up_file)
            
            content["coordinates"]=content["Address"].apply(ArcGIS().geocode,timeout = 2)
            content['Latitude'] = content['coordinates'].apply(lambda x: x.latitude if x != None else None)
            content['Longitude'] = content['coordinates'].apply(lambda x: x.longitude if x != None else None)

            content.to_csv("uploaded_" + up_file.filename)

            return render_template("index.html")
    except:
        return render_template("index.html", )

@app.route('/display',  methods=["POST"])
def display():
    try:
        if request.method == 'POST':
            return render_template("index.html", text = content.to_html(), btn = "download.html")
    except:
        return render_template("index.html")

@app.route('/download')
def download():
    return send_file("uploaded_"+up_file.filename, as_attachment = True)

if __name__ == "__main__":
    app.debug = True
    app.run()