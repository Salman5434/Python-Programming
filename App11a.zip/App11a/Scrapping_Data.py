import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime
from flask import Flask, render_template, request
import threading
import sqlite3

def Data_Scrapper(link):
    r1 = requests.get(link)
    c1 = r1.content
    soup_1 = BeautifulSoup(c1, "html.parser")
    all_1 = soup_1.find_all("table",{"id":"hist"})
    return all_1

x1 = Data_Scrapper("https://www.exchangerates.org.uk/USD-PKR-exchange-rate-history.html")
l1 = []

list1 = x1[0].find_all("tr",{"class":"colone"})
list2 = x1[0].find_all("tr",{"class":"coltwo"})

def USD_To_PKR_Data(LIST):
    for i in LIST:    
        d = {}
        date_time_str = i.find_all("td")[0].text
        date_time_obj = datetime.strptime(date_time_str, '%A %d %B %Y')
        d["Date"] = date_time_obj
        d["Price"] = i.find_all("td")[1].text.replace("1 USD = ","").replace(" PKR","")
        l1.append(d)


x2 = Data_Scrapper("https://www.exchangerates.org.uk/PKR-USD-exchange-rate-history.html")
l2 = []

list3 = x2[0].find_all("tr",{"class":"colone"})
list4 = x2[0].find_all("tr",{"class":"coltwo"})

def PKR_To_USD_Data(LIST):
    for i in LIST:    
        d = {}
        date_time_str = i.find_all("td")[0].text
        date_time_obj = datetime.strptime(date_time_str, '%A %d %B %Y')
        d["Date"] = date_time_obj
        d["Price"] = i.find_all("td")[1].text.replace("1 PKR = ","").replace(" USD","")
        l2.append(d)


def Csv_file(LIST, filename):
    df = pd.DataFrame(LIST)
    df = df.sort_values(['Date'])
    df.to_csv(filename, index = False)


USD_To_PKR_Data(list1)
USD_To_PKR_Data(list2)
Csv_file(l1, "USD-to-PKR.csv")
l1 = pd.DataFrame(l1)

PKR_To_USD_Data(list3)
PKR_To_USD_Data(list4)
Csv_file(l2, "PKR-to-USD.csv")
l2 = pd.DataFrame(l2)