import requests
from bs4 import BeautifulSoup
import pandas as pd
import datetime
from flask import Flask, render_template, request
import threading
import sqlite3
import time
import Scrapping_Data

app = Flask(__name__)


def Create_Table():
    conn = sqlite3.connect("lite.db")
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS database (USD_Price INTEGER, PKR_Price INTEGER, Time TEXT)")
    conn.commit()
    conn.close()

def Insert_Values(Usd, Rs, timee):
    conn = sqlite3.connect("lite.db")
    cur = conn.cursor()
    cur.execute("INSERT INTO database VALUES(?,?,?)",(Usd, Rs, timee,))
    conn.commit()
    conn.close()

def Updated_Values():
    conn = sqlite3.connect("lite.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM database")
    result = list(cur.fetchall())
    global Dollar_value, Rupee_value, timee_stamp
    Dollar_value = [i[0] for i in result]
    Rupee_value = [i[1] for i in result]
    timee_stamp = [i[2] for i in result]


def Tick_Data():
    global pkr
    
    while True:
        r3 = requests.get("https://www.x-rates.com/table/?from=USD&amount=1")
        c3 = r3.content
        soup3 = BeautifulSoup(c3, "html.parser")
        
        try:
            if soup3.find("table", {"class" : "tablesorter ratesTable"}).text is not None:
                Usdt = soup3.find("table", {"class" : "tablesorter ratesTable"}).text
                Usdt = Usdt.split()
                index = Usdt.index("Pakistani")
                pkr = Usdt[index+2:index+4]
        except:
            pkr = [None, None]

        print("-----------------")
        print(pkr[0])
        print(pkr[1])
        print("-----------------")

        Create_Table()
        currentDateTime = datetime.datetime.now()
        Insert_Values(float(pkr[0]), float(pkr[1]), currentDateTime)
        Updated_Values()
        time.sleep(20)


@app.route('/')
def home():
    return render_template("home.html", Pkrt = pkr[1], Usdt = pkr[0])

@app.route('/Return', methods = ["POST"])
def Return():
    return render_template("home.html", Pkrt = pkr[1], Usdt = pkr[0])

@app.route('/USD_To_PKR_Data', methods = ['POST'])
def display():
    try:
        if request.method == 'POST':
            return render_template("USD_To_PKR.html", datafr = Scrapping_Data.l1.to_html())
    except:
        return render_template("home.html")

@app.route('/PKR_To_USD_Data', methods = ['POST'])
def displays():
    try:
        if request.method == 'POST':
            return render_template("PKR_To_USD.html", datafr1 = Scrapping_Data.l2.to_html())
    except:
        return render_template("home.html")

@app.route('/Tick_Graph')
def showDataUSD():
    return render_template("graphs.html", y = Dollar_value[-100:], x = timee_stamp[-100:])

@app.route('/Weekly_Graph')
def weeklyDataUSD():
    data = pd.read_csv("USD-to-PKR.csv", parse_dates = ['Date'])
    data['Week'] = data['Date'].dt.strftime('%U - % Y')
    wk_Avg = data.groupby(['Week']).mean()
    return render_template("graphs.html", y = list(wk_Avg['Price']), x = list(wk_Avg.index))

@app.route('/Monthly_Graph')
def monthlyDataUSD():
    data = pd.read_csv("USD-to-PKR.csv", parse_dates = ['Date'])
    data['Month'] = data['Date'].dt.strftime('%m - %Y')
    Mnt_Avg = data.groupby(['Month']).mean()
    return render_template("graphs.html", y = list(Mnt_Avg['Price']), x = list(Mnt_Avg.index))

@app.route('/Tick_Graph1')
def showDataPKR():
    return render_template("graphs1.html", y = Rupee_value[-100:], x = timee_stamp[-100:])
    
@app.route('/Weekly_Graph1')
def weeklyDataPKR():
    data = pd.read_csv("PKR-to-USD.csv", parse_dates = ['Date'])
    data['Week'] = data['Date'].dt.strftime('%U - % Y')
    wk_Avg1 = data.groupby(['Week']).mean()
    return render_template("graphs1.html", y = list(wk_Avg1['Price']), x = list(wk_Avg1.index))

@app.route('/Monthly_Graph1')
def monthlyDataPKR():
    data = pd.read_csv("PKR-to-USD.csv", parse_dates = ['Date'])
    data['Month'] = data['Date'].dt.strftime('%m - %Y')
    Mnt_Avg1 = data.groupby(['Month']).mean()
    return render_template("graphs1.html", y = list(Mnt_Avg1['Price']), x = list(Mnt_Avg1.index))


if __name__ == "__main__":
    thread1 = threading.Thread(target = Tick_Data).start()
    thread2 = threading.Thread(target = app.run(debug = True)).start()