import requests
from bs4 import BeautifulSoup
import pandas
from datetime import datetime
import matplotlib.pyplot as plt
from flask import Flask, render_template, request
import threading
import sqlite3

app = Flask(__name__)

r1 = requests.get("https://www.exchangerates.org.uk/USD-PKR-exchange-rate-history.html")
c1 = r1.content
soup_1 = BeautifulSoup(c1, "html.parser")

all_1 = soup_1.find_all("table",{"id":"hist"})

list1 = all_1[0].find_all("tr",{"class":"colone"})
list2 = all_1[0].find_all("tr",{"class":"coltwo"})

x1 = len(list1)
y1 = len(list2)
l1 = []

for i in range(x1):
    d1 = {}
    date_time_str1 = list1[i].find_all("td")[0].text
    date_time_obj1 = datetime.strptime(date_time_str1, '%A %d %B %Y')
                
    d1["Date"] = date_time_obj1
    d1["Price"] = list1[i].find_all("td")[1].text.replace("1 USD = ","").replace(" PKR","")
                
    l1.append(d1)

for i in range(y1):
    d1 = {}
    date_time_str1 = list2[i].find_all("td")[0].text        
    date_time_obj1 = datetime.strptime(date_time_str1, '%A %d %B %Y')
                
    d1["Date"] = date_time_obj1
    d1["Price"] = list2[i].find_all("td")[1].text.replace("1 USD = ","").replace(" PKR","")

    l1.append(d1)

df1 = pandas.DataFrame(l1)
df1 = df1.sort_values(['Date'], ascending = False)
df1.to_csv("USD-to-PKR.csv", index = False)

#df["Price"] = df["Price"].astype(float)
#df.plot(x ='Date', y='Price', kind = 'area')

#plt.show()

#plt.savefig('my_plot.png')


r2 = requests.get("https://www.exchangerates.org.uk/PKR-USD-exchange-rate-history.html")
c2 = r2.content
soup_2 = BeautifulSoup(c2, "html.parser")

all_2 = soup_2.find_all("table",{"id":"hist"})

list3 = all_2[0].find_all("tr",{"class":"colone"})
list4 = all_2[0].find_all("tr",{"class":"coltwo"})

x2 = len(list3)
y2 = len(list4)
l2 = []

for i in range(x2):
    d2 = {}
    date_time_str2 = list3[i].find_all("td")[0].text
    date_time_obj2 = datetime.strptime(date_time_str2, '%A %d %B %Y')
                
    d2["Date"] = date_time_obj2
    d2["Price"] = list3[i].find_all("td")[1].text.replace("1 PKR = ","").replace(" USD","")
                
    l2.append(d2)

for i in range(y2):
    d2 = {}
    date_time_str2 = list4[i].find_all("td")[0].text        
    date_time_obj2 = datetime.strptime(date_time_str2, '%A %d %B %Y')
                
    d2["Date"] = date_time_obj2
    d2["Price"] = list4[i].find_all("td")[1].text.replace("1 PKR = ","").replace(" USD","")

    l2.append(d2)

df2 = pandas.DataFrame(l2)
df2 = df2.sort_values(['Date'], ascending = False)
df2.to_csv("PKR-to-USD.csv", index = False)



r3 = requests.get("https://www.google.com/finance/quote/USD-PKR?sa=X&ved=2ahUKEwjGt8is3JP6AhVDxQIHHfPLCioQmY0JegQICBAb")
c3 = r3.content
soup3 = BeautifulSoup(c3, "html.parser")
global USDt
USDt = soup3.find("div",{"class":"YMlKec fxKbKc"}).text
# Create_Table()
# currentDateTime = datetime.datetime.now()
# print(currentDateTime)
# Insert_Values(float(USDt), currentDateTime)



@app.route('/')
def home():
    return render_template("home.html", USDt = USDt)

@app.route('/Return', methods = ["POST"])
def Return():
    return render_template("home.html", USDt = USDt)

@app.route('/USD_To_PKR_Data', methods = ['POST'])
def display():
    try:
        if request.method == 'POST':
            return render_template("USD_To_PKR.html", datafr = df1.to_html())
    except:
        return render_template("home.html")

@app.route('/PKR_To_USD_Data', methods = ['POST'])
def displays():
    try:
        if request.method == 'POST':
            return render_template("PKR_To_USD.html", datafr1 = df2.to_html())
    except:
        return render_template("home.html")

@app.route('/Conversion_To_USD', methods = ['POST'])
def USD():
    if request.method == 'POST':
        PKR_values =  request.form["PKR_value"]*230
        return render_template("Conversion_To_USD.html", PKR_values = PKR_values)

if __name__ == "__main__":
    app.debug = True
    app.run()









