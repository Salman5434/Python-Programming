import requests
from bs4 import BeautifulSoup
import pandas as pd
import datetime
from flask import Flask, render_template, request
import threading
import sqlite3
import time

class Databases:
    def __init__(self, dtb):
        self.conn = sqlite3.connect(dtb)
        self.cur = self.conn.cursor()
        self.cur.execute("CREATE TABLE IF NOT EXISTS database (USD_Price INTEGER, PKR_Price INTEGER, Time TEXT)")
        self.conn.commit()

    def Insert_Values(self, Usd, Rs, timee):
        self.cur.execute("INSERT INTO database VALUES(?,?,?)",(Usd, Rs, timee,))
        self.conn.commit()

    def Updated_Values(self):
        self.cur.execute("SELECT * FROM database")
        result = list(self.cur.fetchall())
        global Dollar_value, Rupee_value, timee_stamp
        Dollar_value = [i[0] for i in result]
        Rupee_value = [i[1] for i in result]
        timee_stamp = [i[2] for i in result]
    
    def __del__(self):
        self.conn.close()