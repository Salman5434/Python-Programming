import requests
from bs4 import BeautifulSoup
import pandas as pd
import datetime
from flask import Flask, render_template, request
import threading
import sqlite3
import time
from Scrapping_Data import Scraping_dataa
import Database

app = Flask(__name__)

def Tick_Data():
    global pkr
    
    while True:
        r3 = requests.get("https://www.x-rates.com/table/?from=USD&amount=1")
        c3 = r3.content
        soup3 = BeautifulSoup(c3, "html.parser")
        
        try:
            if soup3.find("table", {"class" : "tablesorter ratesTable"}).text is not None:
                Usdt = soup3.find("table", {"class" : "tablesorter ratesTable"}).text
                Usdt = Usdt.split()
                index = Usdt.index("Pakistani")
                pkr = Usdt[index+2:index+4]
        except:
            pkr = [None, None]

        print("-----------------")
        print(pkr[0])
        print(pkr[1])
        print("-----------------")

        db = Database.Databases("lite.db")
        currentDateTime = datetime.datetime.now()
        db.Insert_Values(float(pkr[0]), float(pkr[1]), currentDateTime)
        db.Updated_Values()
        time.sleep(20)


object1 = Scraping_dataa()
object2 = Scraping_dataa()

l1 =[]
l2 = []

soup = object1.Data_Scrapper("https://www.exchangerates.org.uk/USD-PKR-exchange-rate-history.html")
all = soup.find_all("table",{"id":"hist"})

list1 = all[0].find_all("tr",{"class":"colone"})
list2 = all[0].find_all("tr",{"class":"coltwo"})

object1.Data(list1, "USD-PKR", "1 USD = ", "", " PKR", "", l1)
object1.Data(list2, "USD-PKR", "1 USD = ", "", " PKR", "", l1)
object1.Csv_file(l1, "USD-to-PKR.csv")
l1 = pd.DataFrame(l1)

soup = object2.Data_Scrapper("https://www.exchangerates.org.uk/PKR-USD-exchange-rate-history.html")
all = soup.find_all("table",{"id":"hist"})

list3 = all[0].find_all("tr",{"class":"colone"})
list4 = all[0].find_all("tr",{"class":"coltwo"})

object2.Data(list3, "PKR-USD", "1 PKR = ", "", " USD", "", l2)
object2.Data(list4, "PKR-USD", "1 PKR = ", "", " USD", "", l2)
object2.Csv_file(l2, "PKR-to-USD.csv")
l2 = pd.DataFrame(l2)


@app.route('/')
def home():
    return render_template("home.html", Pkrt = pkr[1], Usdt = pkr[0])

@app.route('/Return', methods = ["POST"])
def Return():
    return render_template("home.html", Pkrt = pkr[1], Usdt = pkr[0])

@app.route('/USD_To_PKR_Data', methods = ['POST'])
def display():
    try:
        if request.method == 'POST':
            return render_template("USD_To_PKR.html", datafr = l1.to_html())
    except:
        return render_template("home.html")

@app.route('/PKR_To_USD_Data', methods = ['POST'])
def displays():
    try:
        if request.method == 'POST':
            return render_template("PKR_To_USD.html", datafr1 = l2.to_html())
    except:
        return render_template("home.html")

@app.route('/Tick_Graph')
def showDataUSD():
    return render_template("graphs.html", y = Database.Dollar_value[-100:], x = Database.timee_stamp[-100:])

@app.route('/Weekly_Graph')
def weeklyDataUSD():
    data = pd.read_csv("USD-to-PKR.csv", parse_dates = ['Date'])
    data['Week'] = data['Date'].dt.strftime('%U - %Y')
    wk_Avg = data.groupby(['Week']).mean()
    return render_template("graphs.html", y = list(wk_Avg['Price']), x = list(wk_Avg.index))

@app.route('/Monthly_Graph')
def monthlyDataUSD():
    data = pd.read_csv("USD-to-PKR.csv", parse_dates = ['Date'])
    data['Month'] = data['Date'].dt.strftime('%m - %Y')
    Mnt_Avg = data.groupby(['Month']).mean()
    return render_template("graphs.html", y = list(Mnt_Avg['Price']), x = list(Mnt_Avg.index))

@app.route('/Tick_Graph1')
def showDataPKR():
    return render_template("graphs1.html", y = Database.Rupee_value[-100:], x = Database.timee_stamp[-100:])
    
@app.route('/Weekly_Graph1')
def weeklyDataPKR():
    data = pd.read_csv("PKR-to-USD.csv", parse_dates = ['Date'])
    data['Week'] = data['Date'].dt.strftime('%U - %Y')
    wk_Avg1 = data.groupby(['Week']).mean()
    return render_template("graphs1.html", y = list(wk_Avg1['Price']), x = list(wk_Avg1.index))

@app.route('/Monthly_Graph1')
def monthlyDataPKR():
    data = pd.read_csv("PKR-to-USD.csv", parse_dates = ['Date'])
    data['Month'] = data['Date'].dt.strftime('%m - %Y')
    Mnt_Avg1 = data.groupby(['Month']).mean()
    return render_template("graphs1.html", y = list(Mnt_Avg1['Price']), x = list(Mnt_Avg1.index))


if __name__ == "__main__":
    thread1 = threading.Thread(target = Tick_Data).start()
    thread2 = threading.Thread(target = app.run(debug = True)).start()