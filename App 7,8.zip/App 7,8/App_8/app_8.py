from flask import Flask, render_template, request
import sqlite3
from statistics import mean
from tkinter import *

app_8 = Flask(__name__)

class Database:
    
    def __init__(self, dtb):
        
        self.conn = sqlite3.connect(dtb, check_same_thread = False)
        print("Db created successfully")
     
        self.cur = self.conn.cursor()

        self.cur.execute("CREATE TABLE IF NOT EXISTS data_set (email TEXT, height INTEGER)")
        print("Table created successfully")

        self.conn.commit()

    def insert_data(self, email, height):
        self.cur.execute("INSERT INTO data_set VALUES (?,?)", (email, height))
        print(email,height)
        self.conn.commit()

    def search(self, email):
        self.cur.execute("SELECT AVG(height) FROM data_set")
        avg_height = self.cur.fetchall()
        print(avg_height)
        return avg_height[0][0]

    def count(self,email):
        self.cur.execute("SELECT COUNT(email) FROM data_set")
        num = self.cur.fetchall()
        return num[0][0]

@app_8.route("/")
def index():
    return render_template("index.html")

@app_8.route("/success/", methods = ["POST"])
def success():
    if request.method == 'POST':
        email = request.form["email_name"]
        height =  request.form["height_name"]
        db.insert_data(email, height)
        return render_template("success.html", email = email, height = height, avg_height = db.search(email), entries = db.count(email))

db = Database("database.db")

if __name__ == '__main__':
    app_8.debug = True
    app_8.run(host = '0.0.0.0')