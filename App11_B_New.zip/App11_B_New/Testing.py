import os
import plotly.graph_objects as go
import matplotlib.pyplot as plt
import plotly.express as px
import pandas as pd
import numpy as np
from datetime import datetime
from statsmodels.tsa.seasonal import seasonal_decompose
import seaborn as sns
import plotly.figure_factory as ff
from keras.models import Sequential
from keras.models import load_model
from keras.layers import LSTM,Dropout,Dense
from sklearn.preprocessing import MinMaxScaler
import warnings
from plotly.subplots import make_subplots
from plotly.graph_objs import Line
from see_rnn import *
from sklearn.metrics import mean_squared_error
warnings.filterwarnings("ignore", category=DeprecationWarning)

df = pd.read_csv('Till 24 nov USD_PKR Historical Data.csv', parse_dates=True)
df = pd.DataFrame(df)
df['Date'] = df['Date'].apply(pd.to_datetime)
df = df.loc[::-1].reset_index(drop=True)
df.set_index('Date',inplace=True)
idx = pd.date_range(start='02-05-2022', end='24-11-2022')
df = df.reindex(idx)
df.index.names = ['Date']
df = df.interpolate(method ='linear', limit_direction ='backward')

df.drop('Open', axis=1, inplace=True)
df.drop('High', axis=1, inplace=True)
df.drop('Low', axis=1, inplace=True)
df.drop('Vol.', axis=1, inplace=True)
df.drop('Change %', axis=1, inplace=True)
df1 = df.copy()

df.to_csv('Till 24 nov USD_PKR Historical Data_1.csv')

size = int(len(df))
df = df.values

df[1:len(df),0]

scaler=MinMaxScaler(feature_range=(0,1))
scaled_data=scaler.fit_transform(df.reshape(-1,1))
df=df.reshape(-1,1)
df=scaler.transform(df)

X_test=[]
for i in range(50,df.shape[0]):
    X_test.append(df[i-50:i,0])
X_test=np.array(X_test)
X_test=np.reshape(X_test,(X_test.shape[0],X_test.shape[1],1))

lstm_model=Sequential()
lstm_model.add(LSTM(units=64,return_sequences=True,input_shape=(X_test.shape[1],1)))
lstm_model.add(LSTM(units=64))
lstm_model.add(Dense(1))
lstm_model.load_weights("my_model.h5")

y_hat = lstm_model.predict(X_test)
y_hat = scaler.inverse_transform(y_hat)

df1 = df1[50:]
df1['Predictions'] = y_hat
df1.to_csv('Till 24 nov USD_PKR Historical Data_2.csv')