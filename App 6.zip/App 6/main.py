from kivy.app import App
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
import json, pandas
from datetime import datetime
from pathlib import Path
import random
import glob

Builder.load_file('design.kv')

class LoginScreen(Screen):
    def Sign_Up(self):
        self.manager.current = "Sign_Up_Screen"
    
    def Login(self, uname, pword):
        with open ("users.json") as file:
            users = json.load(file)

        if uname in users and users[uname]["password"] == pword:
            self.manager.current = "Login_Screen_Success"

        else:
            self.ids.login_wrong.text = "Wrong username or password"


class RootWidget(ScreenManager):
    pass


class SignUpScreen(Screen):
    def add_user(self, uname, pword):
        with open ("users.json") as file:
            users = json.load(file)

        users[uname] = {'username': uname, 'password': pword, 'created': datetime.now().strftime("%Y-%m-%d,%H-%M-%S")}
        print(users)

        with open ("users.json", 'w') as file:
            json.dump(users, file)

        self.manager.current = "Sign_Up_Screen_Success"


class SignUpScreenSuccess(Screen):
    def go_to_login(self):
        self.manager.transition.direction = "right"
        self.manager.current = "Login_Screen"


class LoginScreenSuccess(Screen):
    def Log_Out(self):
        self.manager.transition.direction = "right"
        self.manager.current = "Login_Screen"

    def get_quotes(self, feel):
        feel = feel.lower()
        available_feelings = glob.glob("quotes/*txt")
        available_feelings = [Path(filename).stem for filename in available_feelings]
        if feel in available_feelings:
            with open(f"quotes/{feel}.txt", encoding = "utf8") as file:
                quotes = file.readlines()

            self.ids.quote.text = random.choice(quotes)
        
        else:
            self.ids.quote.text = "Choose between happy, sad, and unloved"


class MainApp(App):
    def build(self):
        return RootWidget()


if __name__ == "__main__":
    MainApp().run()